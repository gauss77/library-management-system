REM INSERTING into LIBRARY.BOOKS
SET DEFINE OFF;
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (95,'peripheral & Component Interface','asdssdsfd','2021-40-04 17:40:05',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (83,'apple','yash','2021-36-04 17:36:57',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (92,'Peripheral and component interface','saaa','2021-39-04 17:39:21',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (161,'Programming in java','Sfa','2021-04-17 23:26:50',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (84,'mac','tim cock','2021-37-04 17:37:07',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (141,'Not assigned','Snajay','2021-04-11 20:43:50','2021-05-05 20:26:19');
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (204,'Dsa','Sdads','2021-04-25 16:48:15',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (99,'Hsdhk ajkjds','kartik','2021-15-04 20:15:24','2021-04-24 20:47:58');
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (91,'Peripheral & Component Interface','adc','2021-38-04 17:38:25',null);
Insert into LIBRARY.BOOKS (ID,NAME,AUTHOR,DATE_CREATED,DATE_UPDATED) values (101,'Kad dc xk xz','Jsd sj sjsa adds','2021-36-04 20:36:49','2021-04-24 20:11:52');
