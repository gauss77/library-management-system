REM INSERTING into LIBRARY.DEPT_SEM_SUBJECT
SET DEFINE OFF;
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (46,'programming in java',61,5,'Computer engineering','5th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (51,'Applied physics',61,1,'Computer engineering','1th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (52,'Database management system',61,3,'Computer engineering','3th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (52,'Database management system',61,4,'Computer engineering','4th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (52,'Database management system',62,5,'Automobile engineering','5th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (82,'Entrepreneurship development & management',61,3,'Computer engineering','3th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (82,'Entrepreneurship development & management',61,5,'Computer engineering','5th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (82,'Entrepreneurship development & management',62,3,'Automobile engineering','3th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (49,'Computer graphics',61,6,'Computer engineering','6th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (101,'Programming in java',61,3,'Computer engineering','3th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (101,'Programming in java',61,4,'Computer engineering','4th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (101,'Programming in java',62,1,'Automobile engineering','1th semester');
Insert into LIBRARY.DEPT_SEM_SUBJECT (SUBJECT_ID,SUBJECT_NAME,DEPT_ID,SEM_ID,DEPT_NAME,SEM_NAME) values (101,'Programming in java',63,3,'Electronics & communication engineering ','3th semester');
