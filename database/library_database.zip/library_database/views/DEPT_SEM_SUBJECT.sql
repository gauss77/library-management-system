--------------------------------------------------------
--  DDL for View DEPT_SEM_SUBJECT
--------------------------------------------------------

  CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "LIBRARY"."DEPT_SEM_SUBJECT" ("SUBJECT_ID", "SUBJECT_NAME", "DEPT_ID", "SEM_ID", "DEPT_NAME", "SEM_NAME") AS 
  select t1.id as subject_id, t1.name as subject_name, t2.dept_id, t2.sem_id,t3.name as dept_name, t4.name as sem_name
from subjects t1 
inner join dept_sem_sub_relation t2 on t1.id = t2.subject_id
inner join departments t3 on t3.id = t2.dept_id
inner join semesters t4 on t4.id = t2.sem_id
;
