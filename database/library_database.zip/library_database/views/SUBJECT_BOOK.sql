--------------------------------------------------------
--  DDL for View SUBJECT_BOOK
--------------------------------------------------------

  CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "LIBRARY"."SUBJECT_BOOK" ("BOOK_NAME", "DEFAULT_BOOK", "BOOK_ID", "SUBJECT_ID", "SUBJECT_NAME") AS 
  select t1.name as book_name, t2.default_book, t2.book_id, t2.subject_id, t3.name 
as subject_name from books t1 
inner join subject_book_rel t2 on t1.id = t2.book_id 
inner join subjects t3 on t3.id = t2.subject_id
;
