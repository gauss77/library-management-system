--------------------------------------------------------
--  DDL for Sequence BOOKS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LIBRARY"."BOOKS_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 221 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
