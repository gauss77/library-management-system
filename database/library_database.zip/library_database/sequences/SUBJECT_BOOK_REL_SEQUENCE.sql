--------------------------------------------------------
--  DDL for Sequence SUBJECT_BOOK_REL_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LIBRARY"."SUBJECT_BOOK_REL_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 161 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
