--------------------------------------------------------
--  DDL for Sequence BOOK_UNITS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LIBRARY"."BOOK_UNITS_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 301 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
