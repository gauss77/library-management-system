--------------------------------------------------------
--  DDL for Sequence SUBJECTS_SEQUENCE
--------------------------------------------------------

   CREATE SEQUENCE  "LIBRARY"."SUBJECTS_SEQUENCE"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 141 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
