--------------------------------------------------------
--  DDL for Trigger SUBMITTED_BOOK_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."SUBMITTED_BOOK_ON_INSERT" 
  BEFORE INSERT ON submitted_books
  FOR EACH ROW
BEGIN
  SELECT submitted_books_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."SUBMITTED_BOOK_ON_INSERT" ENABLE;
