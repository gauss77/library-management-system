--------------------------------------------------------
--  DDL for Trigger SEMESTER_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."SEMESTER_ON_INSERT" 
  BEFORE INSERT ON semesters
  FOR EACH ROW
BEGIN
  SELECT semesters_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."SEMESTER_ON_INSERT" ENABLE;
