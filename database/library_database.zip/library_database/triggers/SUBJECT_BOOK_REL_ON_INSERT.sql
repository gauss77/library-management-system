--------------------------------------------------------
--  DDL for Trigger SUBJECT_BOOK_REL_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."SUBJECT_BOOK_REL_ON_INSERT" 
  BEFORE INSERT ON subject_book_rel
  FOR EACH ROW
BEGIN
  SELECT subject_book_rel_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."SUBJECT_BOOK_REL_ON_INSERT" ENABLE;
