--------------------------------------------------------
--  DDL for Trigger MAIL_SEND_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."MAIL_SEND_ON_INSERT" 
  BEFORE INSERT ON mail_send
  FOR EACH ROW
BEGIN
  SELECT mail_send_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."MAIL_SEND_ON_INSERT" ENABLE;
