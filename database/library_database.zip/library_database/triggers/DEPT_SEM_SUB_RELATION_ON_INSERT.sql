--------------------------------------------------------
--  DDL for Trigger DEPT_SEM_SUB_RELATION_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."DEPT_SEM_SUB_RELATION_ON_INSERT" 
  BEFORE INSERT ON dept_sem_sub_relation
  FOR EACH ROW
BEGIN
  SELECT dept_sem_sub_relation_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."DEPT_SEM_SUB_RELATION_ON_INSERT" ENABLE;
