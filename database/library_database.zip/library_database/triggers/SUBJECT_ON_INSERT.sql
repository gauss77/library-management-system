--------------------------------------------------------
--  DDL for Trigger SUBJECT_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."SUBJECT_ON_INSERT" 
  BEFORE INSERT ON subjects
  FOR EACH ROW
BEGIN
  SELECT subjects_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."SUBJECT_ON_INSERT" ENABLE;
