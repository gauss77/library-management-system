--------------------------------------------------------
--  DDL for Trigger DEPARTMENT_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."DEPARTMENT_ON_INSERT" 
  BEFORE INSERT ON departments
  FOR EACH ROW
BEGIN
  SELECT departments_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."DEPARTMENT_ON_INSERT" ENABLE;
