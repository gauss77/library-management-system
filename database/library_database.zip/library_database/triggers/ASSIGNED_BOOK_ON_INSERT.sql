--------------------------------------------------------
--  DDL for Trigger ASSIGNED_BOOK_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."ASSIGNED_BOOK_ON_INSERT" 
  BEFORE INSERT ON assigned_books
  FOR EACH ROW
BEGIN
  SELECT assigned_books_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."ASSIGNED_BOOK_ON_INSERT" ENABLE;
