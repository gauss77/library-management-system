--------------------------------------------------------
--  DDL for Trigger BOOK_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."BOOK_ON_INSERT" 
  BEFORE INSERT ON books
  FOR EACH ROW
BEGIN
  SELECT books_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."BOOK_ON_INSERT" ENABLE;
