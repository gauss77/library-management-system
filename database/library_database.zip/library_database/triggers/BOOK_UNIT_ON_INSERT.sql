--------------------------------------------------------
--  DDL for Trigger BOOK_UNIT_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."BOOK_UNIT_ON_INSERT" 
  BEFORE INSERT ON book_units
  FOR EACH ROW
BEGIN
  SELECT book_units_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."BOOK_UNIT_ON_INSERT" ENABLE;
