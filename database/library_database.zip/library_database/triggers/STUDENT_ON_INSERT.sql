--------------------------------------------------------
--  DDL for Trigger STUDENT_ON_INSERT
--------------------------------------------------------

  CREATE OR REPLACE NONEDITIONABLE TRIGGER "LIBRARY"."STUDENT_ON_INSERT" 
  BEFORE INSERT ON students
  FOR EACH ROW
BEGIN
  SELECT students_sequence.nextval
  INTO :new.id
  FROM dual;
END;
/
ALTER TRIGGER "LIBRARY"."STUDENT_ON_INSERT" ENABLE;
