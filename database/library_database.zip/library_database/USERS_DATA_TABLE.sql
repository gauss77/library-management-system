REM INSERTING into LIBRARY.USERS
SET DEFINE OFF;
Insert into LIBRARY.USERS (ID,USERNAME,PASSWORD,ROLE) values (1,'admin','root','admin');
Insert into LIBRARY.USERS (ID,USERNAME,PASSWORD,ROLE) values (2,'user','user123','user');
