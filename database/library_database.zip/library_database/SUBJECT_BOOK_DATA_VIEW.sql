REM INSERTING into LIBRARY.SUBJECT_BOOK
SET DEFINE OFF;
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('apple',0,83,52,'Database management system');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('apple',0,83,82,'Entrepreneurship development & management');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Peripheral and component interface',0,92,49,'Computer graphics');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Peripheral and component interface',0,92,81,'Computer system');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Peripheral and component interface',0,92,82,'Entrepreneurship development & management');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Hsdhk ajkjds',1,99,52,'Database management system');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Hsdhk ajkjds',0,99,82,'Entrepreneurship development & management');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Peripheral & Component Interface',0,91,81,'Computer system');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Kad dc xk xz',1,101,82,'Entrepreneurship development & management');
Insert into LIBRARY.SUBJECT_BOOK (BOOK_NAME,DEFAULT_BOOK,BOOK_ID,SUBJECT_ID,SUBJECT_NAME) values ('Kad dc xk xz',0,101,52,'Database management system');
